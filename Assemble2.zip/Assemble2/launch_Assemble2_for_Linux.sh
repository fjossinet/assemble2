#!/bin/bash

cd "`dirname "$0"`"

java -Xms500M -Xmx500M -jar assemble2.jar start